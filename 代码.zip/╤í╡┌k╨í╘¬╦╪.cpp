#include <bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10;
vector<int> v;
int num_root, n, m;
int L[N << 2], R[N << 2], tree[N << 2], root[N], a[N];
int get_id(int x) {  // 离散化
    return lower_bound(v.begin(), v.end(), x) - v.begin() + 1;
}
void update(int l, int r, int& k, int x, int pos) {
    tree[++num_root] = tree[x] + 1;
    L[num_root] = L[x];
    R[num_root] = R[x];
    k = num_root;
    if (l == r)
        return;
    int mid = (l + r) >> 1;
    if (mid >= pos)
        update(l, mid, L[k], L[x], pos);
    else
        update(mid + 1, r, R[k], R[x], pos);
}
int query(int l, int r, int k, int x, int ik) {
    if (l == r)
        return l;
    int mid = (l + r) >> 1;
    int sum = tree[L[k]] - tree[L[x]];
    if (sum >= ik)
        return query(l, mid, L[k], L[x], ik);
    return query(mid + 1, r, R[k], R[x], ik - sum);
}
void init() {
    v.clear();
    num_root = 0;
}
int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    init();
    scanf("%d%d", &n, &m);  // n为数组中元素个数，m为询问次数
    for (int i = 1; i <= n; i++) {
        scanf("%d", &a[i]);
        v.push_back(a[i]);
    }
    sort(v.begin(), v.end());
    v.erase(unique(v.begin(), v.end()), v.end());
    int sum = v.size();
    for (int i = 1; i <= n; i++)
        update(1, sum, root[i], root[i - 1], get_id(a[i]));
    while (m--) {
        int s = 1, t = n, k;  // 查询区间[s, t]之中第k小的数
        scanf("%d", &k);
        int ans = query(1, sum, root[t], root[s - 1], k) - 1;
        printf("%d\n", v[ans]);
    }
}
